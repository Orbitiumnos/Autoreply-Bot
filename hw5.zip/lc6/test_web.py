#from sre_constants import SUCCESS
import encodings
from getpass import getpass
from unittest.mock import patch
from urllib import response

import pytest
import requests

URL_GITHUB_API = "https://api.github.com"
URL_AUTH_TEST = "https://jigsaw.w3.org/HTTP/Basic"


def test_simple():
    assert 1 == 1


@pytest.mark.slow
def test_simple():
    assert 1 == 1


def test_github_api_status():
    response = requests.get(URL_GITHUB_API)
    assert response.status_code < 400


@pytest.mark.integration_test
@pytest.mark.parametrize(
    "target_url, expected_outcome",
    [
        (URL_GITHUB_API, True),
        (URL_AUTH_TEST, False),
    ]
)


def test_jigsaw_api_status(target_url, expected_outcome):
    response = requests.get(target_url)
    #from pdb import set_trace; set_trace()
    #assert bool(response.status_code)
    assert expected_outcome == bool(response)


def test_auth_website():
    response = requests.get(URL_AUTH_TEST, auth=("user", "user"))
    assert 400 <= response.status_code < 500


@patch('test_web.getpass')
def test_auth_website_2(mock_getpass):
    mock_getpass.return_value = "guest"
    response = requests.get(URL_AUTH_TEST, auth=("guest", getpass()))
    assert True <= bool(response.status_code)

from argparse import Namespace
DEFAULT_ENCODING = "utf-8"
DEFAULT_STATUS_CODE = 200
GITHUB_API_RESPONSE_FILEPATH = "github_api_response.txt"


def build_response_mock_from_content(content, encoding=DEFAULT_ENCODING, status_code=DEFAULT_STATUS_CODE):
    response = Namespace(
        content=content,
        encoding=encoding,
        text=content.decode(encoding), 
        status_code=status_code
    )
    return response


@patch("requests.get")
def test_we_can_mock_web(mock_requests_get):
    with open(GITHUB_API_RESPONSE_FILEPATH,"rb") as content_fin:
        content = content_fin.read()
        mock_requests_get.return_value = build_response_mock_from_content(
            content=content,
        )

    response = requests.get(URL_GITHUB_API)
    assert response.status_code == 200
    assert "github" in response.text