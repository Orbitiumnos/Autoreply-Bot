from concurrent.futures.thread import _worker
import re
import json
import sys
import yaml
import logging
import logging.config

from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter, FileType, ArgumentTypeError
from io import TextIOWrapper
from collections import defaultdict
from typing import Dict, List
#from lib2to3.pgen2.literals import simple_escapes
from struct import pack, unpack, calcsize

DEFAULT_DATASET_PATH = r"C:\Users\Nikolay\repos\PythonCourse\hw2\wikipedia_utf8.txt"
DEFAULT_INVERTED_INDEX_STORE_PATH = r"C:\Users\Nikolay\repos\PythonCourse\lc4\inverted.index"
DEFAULT_STORE_STRATEGY = "struct"
DEFAULT_LOAD_STRATEGY = "struct"
APPLICATION_NAME = 'inverted_index'
DEFAULT_LOGGING_CONFIG_FILEPATH = r"C:\Users\Nikolay\repos\PythonCourse\lc4\logging.conf.yml"


logger = logging.getLogger(APPLICATION_NAME) # __name__


class EncodedFileType(FileType):
    """encoding for FileType"""

    def __call__(self, string):
        if string == '-':
            if 'r' in self._mode:
                stdin = TextIOWrapper(sys.stdin.buffer, encoding=self._encoding)
                return stdin
            elif 'w' in self._mode:
                stdout = TextIOWrapper(sys.stdout.buffer, encoding=self._encoding)
                return stdout
            else:
                msg = 'argument "-" with mode %r' % self._mode
                raise ValueError(msg)

        try:
            return open(string, self._mode, self._bufsize, self._encoding,
                        self._errors)
        except OSError as e:
            args = {'filename': string, 'error': e}
            message = "can't open '%(filename)s': %(error)s"
            raise ArgumentTypeError(message % args)


class InvertedIndex:
    """
    InvertedIndex class povides functionality to work with InvertedIndex object

    use InvertedIndex module to:
    1. InvertedIndex.query(self, words: List[str]) -> List[int] - load InvertedIndex from path
    2. InvertedIndex.dump(self, filepath: str) - use InvertedIndex to dump it into disk
    3. InvertedIndex.load(cls, filepath: str) - search words in InvertedIndex
    """

    def __init__(self, index_dict: dict):
        self.index_dict = index_dict

    def __eq__(self, rhs):
        outcome = (
            (self.index_dict.keys() == rhs.index_dict.keys())
            and
            (list(map(list, rhs.index_dict.values())) == list(map(list, self.index_dict.values())))
        )
        return outcome

    def __repr__(self):
        return str(self.index_dict)

    def query(self, words: List[str]) -> List[int]:
        """
        InvertedIndex.query(self, words: List[str]) -> List[int]

        load InvertedIndex from path
        """

        assert isinstance(words, list), (
            "query should be provided with a list of words, but provided: "
            f"{repr(words)}"
        )

        logger.info(f"query inverted index with request {repr(words)}") #file=sys.stderr

        search_words = list(filter(None, words))
        search_words = list(map(lambda x: x.lower(), search_words))
        search_words = set(search_words)
        similar_words = search_words & set(self.index_dict.keys())

        logger.debug(similar_words, self.index_dict)

        if len(search_words) != len(similar_words):
            return []
        query_document_ids = set()

        for term in similar_words:
            if len(query_document_ids) == 0:
                query_document_ids = query_document_ids | set(self.index_dict[term])
            else:
                query_document_ids = query_document_ids & set(self.index_dict[term])
        return list(query_document_ids)


    def dump(self, filepath: str) -> None:
        """
        InvertedIndex.dump(self, filepath: str)

        use InvertedIndex to dump it into disk
        """

        with open(filepath, 'w', encoding="utf-8") as out_file:
            term_doc_id_to_dump = {idx: list(ids) for idx, ids in self.index_dict.items()}
            json.dump(term_doc_id_to_dump, out_file, sort_keys = False, indent = 4,
               ensure_ascii = False)

    @classmethod
    def load(cls, filepath: str) -> 'InvertedIndex':
        """
        InvertedIndex.load(cls, filepath: str)

        search words in InvertedIndex
        """

        with open(filepath, "r", encoding="utf-8") as out_file:
            return InvertedIndex(index_dict=json.load(out_file))


    def binary_dump(self, filepath: str) -> None:
        """
        InvertedIndex.dump(self, filepath: str)

        use InvertedIndex to dump it into disk
        """

        with open(filepath, 'wb') as out_file:
            dict_len = len(self.index_dict)
            out_file.write(pack(">i", dict_len))
            for word, doc_id in self.index_dict.items():
                word = word.encode()
                word_len = len(word)
                out_file.write(pack(">H", word_len))
                out_file.write(pack(">" + str(word_len) + "s", word))
                out_file.write(pack(">H", len(doc_id)))
                out_file.write(pack(">" + str(len(doc_id)) + "H", *list(doc_id)))

    @classmethod
    def binary_load(cls, filepath: str) -> 'InvertedIndex':
        """
        InvertedIndex.load(cls, filepath: str)

        load words in InvertedIndex
        """

        index_dict = defaultdict(set)
        with open(filepath, 'rb') as file:
            dict_len = file.read(calcsize(">i"))
            dict_len = unpack(">i", dict_len)[0]
            for _ in range(dict_len):
                # распаковываю слова
                word_len = file.read(calcsize(">H"))
                word_len = unpack(">H", word_len)[0]
                doc_id = unpack(">" + str(word_len) + "s",
                              file.read(word_len))[0]
                doc_id = doc_id.decode()

                # распаковываю список статей
                id_len = file.read(calcsize(">H"))
                id_len = unpack(">H", id_len)[0]
                ids = file.read(id_len * calcsize(">H"))
                ids = set(unpack(">" + str(id_len) + "H", ids))
                index_dict[doc_id] = ids
            return InvertedIndex(index_dict=index_dict)


def load_documents(filepath: str) -> Dict[int, str]:
    """
    load_documents(filepath: str) -> Dict[int, str]

    words to dictionary
    """

    article_words = {}
    with open(filepath, "r") as file:
        for line in file:
            try:
                doc_id, content = line.lower().split('\t', 1)
                doc_id = int(doc_id)
                content = content.rstrip()
                if content != '':
                    article_words[doc_id] = content
            except:
                pass

    return article_words


def build_inverted_index(documents: Dict[int, str]) -> InvertedIndex:
    """
    build_inverted_index(documents: Dict[int, str]) -> InvertedIndex

    dictionary to InvertedIndex
    """

    index_dict = defaultdict(set)

    for doc_id, text in documents.items():
        unfiltered_words = re.split(r"\W+", text)
        words = filter(None, unfiltered_words) # для удаления пустых элементов
        for word in words:
            if doc_id is not None:
                index_dict[word].add(doc_id)

    return InvertedIndex(index_dict=index_dict)


def callback_build(arguments):
    """callback_build"""

    return process_build(arguments.dataset_filepath, \
        arguments.inverted_index_filepath, arguments.store_strategy)


def process_build(dataset_filepath, inverted_index_filepath, store_strategy):
    """process_build"""

    logger.debug(f"build from {dataset_filepath} to {inverted_index_filepath}") #file=sys.stderr

    if store_strategy == "struct":
        documents = load_documents(dataset_filepath)
        inverted_index = build_inverted_index(documents)
        inverted_index.binary_dump(inverted_index_filepath)
    else:
        documents = load_documents(dataset_filepath)
        inverted_index = build_inverted_index(documents)
        inverted_index.dump(inverted_index_filepath)



def callback_query(arguments):
    """callback_query"""

    if arguments.queries is not None:
        process_queries(arguments.inverted_index_filepath, \
            arguments.queries, arguments.load_strategy)
    else:
        process_file_queries(arguments.inverted_index_filepath, \
            arguments.query_file, arguments.load_strategy)


def process_queries(inverted_index_filepath, queries, load_strategy):
    """process_queries"""

    logger.debug(f"read queries from {queries}") #file=sys.stderr
    if load_strategy == 'struct':
        inverted_index = InvertedIndex.binary_load(inverted_index_filepath)
    else:
        inverted_index = InvertedIndex.load(inverted_index_filepath)

    for query in queries:
        tmp_relevant_ids: list = inverted_index.query(query)
        logger.debug(','.join(str(w) for w in tmp_relevant_ids))


def process_file_queries(inverted_index_filepath, query_file, load_strategy):
    """process_queries"""

    #print(f"read queries from {query_file}", file=sys.stderr)
    if load_strategy == 'struct':
        inverted_index = InvertedIndex.binary_load(inverted_index_filepath)
    else:
        inverted_index = InvertedIndex.load(inverted_index_filepath)

    #print(query_file)
    for line in query_file:
        if line is None:
            continue
        query = list(map(str, line.strip().split()))
        #tmp_relevant_ids = inverted_index.query(query)
        tmp_relevant_ids: list = inverted_index.query(query)
        print(','.join(str(w) for w in tmp_relevant_ids))


def setup_parser(parser):
    """ArgumentParser from argparse"""

    # BUILD

    subparsers = parser.add_subparsers(help="choose command")

    build_parser = subparsers.add_parser(
        "build",
        help="build inverted index and save in binary format into hard drive",
        formatter_class=ArgumentDefaultsHelpFormatter,
    )

    build_parser.add_argument(
        "-d", "--dataset", dest="dataset_filepath",
        default=DEFAULT_DATASET_PATH,
        help="path to dataset to load, default path is %(default)s",
    )

    build_parser.add_argument(
        "-s", "--strategy", dest="store_strategy",
        choices=['json', 'struct'],
        default=DEFAULT_STORE_STRATEGY,
        help="store strategy, default strategy is %(default)s",
    )

    build_parser.add_argument(
        "-o", "--output", dest="inverted_index_filepath",
        default=DEFAULT_INVERTED_INDEX_STORE_PATH,
        help="path to store inverted index in a binary format, \
             default path is %(default)s",
    )

    build_parser.set_defaults(callback=callback_build)

    # QUERY

    query_parser = subparsers.add_parser(
        "query",
        help="query inverted index",
        formatter_class=ArgumentDefaultsHelpFormatter,
    )

    query_parser.add_argument(
        "-i ", "--index", default=DEFAULT_INVERTED_INDEX_STORE_PATH,
        dest="inverted_index_filepath",
        help="path to read, default path is %(default)s",
    )

    query_parser.add_argument(
        "-s", "--strategy", dest="load_strategy",
        choices=['json', 'struct'],
        default=DEFAULT_LOAD_STRATEGY,
        help="store strategy, default strategy is %(default)s",
    )

    query_file_group = query_parser.add_mutually_exclusive_group(required=False)

    query_file_group.add_argument(
        "--query-file-utf8", dest="query_file",
        type=EncodedFileType("r", encoding="utf-8"),
        default=TextIOWrapper(sys.stdin.buffer, encoding="utf-8"),
        help="query file with queries for inverted index",
    )

    query_file_group.add_argument(
        "--query-file-cp1251", dest="query_file",
        type=EncodedFileType("r", encoding="cp1251"),
        default=TextIOWrapper(sys.stdin.buffer, encoding="cp1251"),
        help="query file with queries for inverted index",
    )

    query_parser.add_argument(
        "-q", "--query",
        nargs="+",
        action="append",
        dest="queries",
        help="queries for inverted index",
    )

    query_parser.set_defaults(callback=callback_query)

    
def setup_logging():
    #logger = logging.getLogger(__name__)
    
    #logging.basicConfig(
    #    filename='test_log.log',
    #    #stream=sys.stderr,
    #    level=logging.DEBUG,
    #)

    print(DEFAULT_LOGGING_CONFIG_FILEPATH)
    with open(DEFAULT_LOGGING_CONFIG_FILEPATH) as config_fin:
        logging.config.dictConfig(yaml.safe_load(config_fin))

    '''
    simple_formatter = logging.Formatter(
        fmt="%(asctime)s %(name)s %(levelname)s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    
    file_handler = logging.FileHandler(
        filename="inverted_index.log",
    )

    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(simple_formatter)

    logger = logging.getLogger(APPLICATION_NAME)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(file_handler)

    #logger = logging.getLogger()
    #logger.addHandler(file_handler)
    '''


def main():
    """Main module"""

    setup_logging()

    parser = ArgumentParser(
        prog="inverted_index_cli.py",
        description='Inverted Index CLI',
        formatter_class=ArgumentDefaultsHelpFormatter,
    )

    setup_parser(parser)
    arguments = parser.parse_args()
    logger.debug('START')
    arguments.callback(arguments)


if __name__ == "__main__":
    main()

'''
debug
info
warning
error
critical
'''
