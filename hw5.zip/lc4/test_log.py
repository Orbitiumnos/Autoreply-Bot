import pytest

def test_import(capsys, caplog):
    import log