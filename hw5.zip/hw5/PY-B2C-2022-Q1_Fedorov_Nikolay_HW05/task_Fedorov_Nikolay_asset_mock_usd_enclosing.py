count = 0

def cur_generator(*args):
    nonlocal count
    generated_currency = 76.32 + 0.1 * count
    count += 1
    return generated_currency

mock_get_usd_course.side_effect = cur_generator