from unittest.mock import MagicMock
mock_calculate_revenue = MagicMock()
mock_calculate_revenue.calculate_revenue.return_value = float('100500.0') 
mock_asset_class.build_from_str.return_value = mock_calculate_revenue