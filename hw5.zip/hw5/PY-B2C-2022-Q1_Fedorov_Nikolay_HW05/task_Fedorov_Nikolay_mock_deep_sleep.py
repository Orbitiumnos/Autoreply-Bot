mock_calculate_revenue = MagicMock()
mock_calculate_revenue.deepest_sleep_function.return_value = 5
@patch('time.sleep')
@patch('sleepy.sleep')