#1

import pytest
from unittest.mock import patch
from asset import print_asset_revenue

@pytest.fixture
def asset_filepath(tmpdir):
    asset_fileio = tmpdir.join("asset.txt") 
    asset_fileio.write("property 100050000 0.1")
    asset_filepath = asset_fileio.strpath
    return asset_filepath

@patch("asset.Asset")
def test_asset_calculate_revenue_always_return_108500(mock_asset_class, asset_filepath, capsys):

    #from unittest.mock import MagicMock
    mock_calculate_revenue = MagicMock()
    mock_calculate_revenue.calculate_revenue.return_value = float('100500.0') 
    mock_asset_class.build_from_str.return_value = mock_calculate_revenue

    periods = [1, 2, 5, 10]

    with open(asset_filepath) as asset_fin:
        print_asset_revenue(asset_fin, periods=periods)
    
    from pdb import set_trace; set_trace()

    captured = capsys.readouterr()

    assert len(periods) == len(captured.out.splitlines())
    for line in captured.out.splitlines():
        assert "100500" in line

#4
'''
from asset import Asset

@patch("cbr.get_usd_course")
def test_can_mock_external_calls(mock_get_usd_course):
    
    mock_get_usd_course.side_effect = [float(76.54), float (77.44), ConnectionError]
    asset_property = Asset(name='property', capital=10**6, interest=0.1)
    
    result = asset_property.calculate_revenue_from_usd(years=1)
    expected_result = pytest.approx(76.54 * 10**5, abs=0.01)
    assert result == expected_result, 'you have {} while should have {}'.format(result, expected_result)

    result = asset_property.calculate_revenue_from_usd(years=1) 
    expected_result = pytest.approx(77.44 * 10**5, abs=0.01)
    assert result == expected_result, 'you have {} while should have {}:'.format(result, expected_result)

    with pytest.raises(ConnectionError):
        asset_property.calculate_revenue_from_usd(years=1)

#5

from unittest.mock import patch
import pytest
from asset import Asset

@patch("cbr.get_usd_course")
def test_can_mock_external_calls_2(mock_get_usd_course):
    
    count = 0

    def cur_generator(*args):
        nonlocal count
        generated_currency = 76.32 + 0.1 * count
        count += 1
        return generated_currency
    
    mock_get_usd_course.side_effect = cur_generator
    
    asset_property = Asset(name="property", capital=10**6, interest=0.1)
    
    #from IPython import embed; embed;

    for iteration in range(2):
        expected_revenue = (76.32 + 0.1 * iteration) * asset_property.capital * asset_property.interest
        calculated_revenue = asset_property.calculate_revenue_from_usd(years=1)
    
        print(iteration, expected_revenue, calculated_revenue)
        #import pdb; pdb.set_trace()

        assert calculated_revenue == pytest.approx(expected_revenue, abs=0.01), (f"incorrect calculated revenue at iteration {iteration}")
'''