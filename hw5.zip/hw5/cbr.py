def get_usd_course():
    raise NotImplementedError