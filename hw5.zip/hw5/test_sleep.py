import pytest
from unittest.mock import patch
import sleep

@patch('sleep.sleep', return_value=3)
def test_sleep_add(mock_sleep_add):
    result = sleep.sleep_add(1, 2)
    expected_result = 3
    assert result == expected_result, 'you have {} while should have {}:'.format(result, expected_result)

@patch('time.sleep', return_value=2)
def test_sleep_multiply(mock_sleep_multiply):
    result = sleep.sleep_multiply(1, 2)
    expected_result = 2
    assert result == expected_result, 'you have {} while should have {}:'.format(result, expected_result)

# pytest -v --cov=sleepy test_sleepy.py