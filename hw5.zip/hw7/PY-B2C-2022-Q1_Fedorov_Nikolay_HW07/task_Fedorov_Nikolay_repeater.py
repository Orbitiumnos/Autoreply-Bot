from contextlib import ContextDecorator
from functools import wraps

def verbose(function):
    """ text """
    @wraps(function)
    def wrapper(*args, **kwargs):
        print("before function call")
        outcome = function(*args, **kwargs)
        print("after function call")
        return outcome

    return wrapper

@verbose
def hello_example(name: str):
    """ text """
    print(f"*** Hello {name}! ***")

# 1.2

def repeater(count):
    """ text """
    def my_decorator(func):
        """ text """
        @wraps(func)
        def wrapped (function_arg1, function_arg2):
            """ text """
            for i in range(count):
                func(function_arg1, function_arg2)
            return i
        return wrapped
    return my_decorator

@repeater(4)
def my_fancy_function(arg_1, arg_2):
    """ text """
    print(arg_1+' '+arg_2)

# 1.3

class verbose_context(ContextDecorator):
    """ text """
    def __enter__(self):
        """ text """
        print('class: before function call')
        return self

    def __exit__(self, *exc):
        """ text """
        print('class: after function call')
        return False

@verbose_context()
def hello(name: str):
    """ text """
    print (f"*** Hello {name}! ***")
