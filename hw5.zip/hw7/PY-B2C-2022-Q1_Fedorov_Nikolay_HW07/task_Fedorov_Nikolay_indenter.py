from contextlib import ContextDecorator

class Indenter(ContextDecorator):
    """ text """

    def __init__(self, indent_str: str = " " * 4, indent_level: int = 0):
        """ text """
        self.indent_str = indent_str
        self.indent_level = indent_level

    def print(self, word):
        """ text """
        self.indent_level -= 1
        print(self.indent_str * self.indent_level + word)
        self.indent_level += 1

    def __enter__(self):
        """ text """
        self.indent_level += 1
        return self

    def __exit__(self, *exc):
        """ text """
        self.indent_level -= 1
        return False
