import pytest
from task_Fedorov_Nikolay_indenter import Indenter

def test_repeater():

    with Indenter() as indent:
        indent.print("hi")
        with indent:
            indent.print("hello")
            with indent: 
                indent.print("bonjour")
        indent.print("hey")
