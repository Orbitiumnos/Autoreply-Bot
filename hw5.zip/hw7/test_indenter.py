import pytest
from task_indenter import Indenter

def _test_indenter(): 
    print('\n')

    indent_str = " " * 4
    indent_level = 0

    with Indenter(indent_str, indent_level) as indent:
        indent.print("hi")
        with indent:
            indent.print("hello")
            with indent: 
                indent.print("bonjour")
        indent.print("hey")

def test_indenter_2():

    @Indenter("--", 0)
    def hello(word):
        print(word)

    hello('lalka')