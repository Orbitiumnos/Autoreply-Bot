import pytest
from task_repeater import hello, hello_example, my_fancy_function, verbose, repeater, verbose_context

def test_verbose(capsys):
    hello_example('Nikolay')
    captured = capsys.readouterr()

    assert 3 == len(captured.out.splitlines())
    for line in captured.out.splitlines():
        assert " " in line

    print(hello_example.__name__)
    print(hello_example.__doc__)

def test_repeater(capsys):
    my_fancy_function('nick','fedorov')
    
    captured = capsys.readouterr()

    assert 4 == len(captured.out.splitlines())
    for line in captured.out.splitlines():
        assert "nick fedorov" in line
    
    print(my_fancy_function.__name__)
    print(my_fancy_function.__doc__)

def test_verbose_context(capsys):
    
    hello('Nikolay')
    captured = capsys.readouterr()

    assert 3 == len(captured.out.splitlines())
    for line in captured.out.splitlines():
        assert " " in line

def test_identer_2():

    @verbose
    @repeater(3) 
    @verbose_context()
    def hello(name: str): 
        """my hello docstring"""
        print(f"Hello {name}")

    expected_result = 'hello'
    result = hello.__name__
    assert result == expected_result, 'you have {} while should have {}:'.format(result, expected_result)

    expected_result = 'my hello docstring'
    result = hello.__doc__
    assert result == expected_result, 'you have {} while should have {}:'.format(result, expected_result)