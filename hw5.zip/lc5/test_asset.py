from argparse import ArgumentDefaultsHelpFormatter, Namespace
from unittest.mock import patch

from asset import process_cli_arguments


@patch("asset.load_asset_from_file")
def test_process_arguments_call_load_once(mock_load_asset_from_file): #caplog
    #"""initial implementation, the way you shoul not rely on"""
    #caplog.set_level("DEBUG")
    with open("asset_example.txt") as fin:
        arguments = Namespace(
            asset_fin=fin,
            periods=[1, 2, 5],
        )
        process_cli_arguments(arguments)

    assert 1 == mock_load_asset_from_file.call_count
    
    """
    load_asset_count = sum(
        1 for log_message in caplog.messages
        if "reading asset file..." in log_message
    )
    assert 1 == load_asset_count
    """