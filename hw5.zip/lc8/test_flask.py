import pytest
from web_hello_world import app as hello_world_app, DEFAULT_GREETING_COUNT


@pytest.fixture
def client():
    with hello_world_app.test_client() as client:
        yield client

def test_service_reply_to_root_path(client):
    response = client.get("/")
    assert 'world' in response.data.decode(response.charset)

def _test_service_reply_to_username(client):
    response = client.get("/hello/Vasya")
    assert 'Vasya' in response.data.decode(response.charset)

def test_service_reply_to_username_with_default_num(client):
    username = 'Vasya'
    expected_greeting_count = DEFAULT_GREETING_COUNT
    response = client.get("/hello/{username}")
    response_text = response.data.decode(response.charset)
    petya_count = response_text.count("Vasya")
    assert expected_greeting_count == petya_count

def test_service_reply_to_username_several_times(client):
    username = 'Petya'
    expected_greeting_count = 15
    response = client.get("/hello/{username}/{expected_greeting_count}")
    response_text = response.data.decode(response.charset)
    petya_count = response_text.count("Petya")
    assert expected_greeting_count == petya_count