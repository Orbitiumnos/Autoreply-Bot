from flask import Flask

app = Flask(__name__)

DEFAULT_GREETING_COUNT = 10

@app.route("/")
def hello_world():
    return "Hello world!"

@app.route("/hello/<username>")
@app.route("/hello/<username>/<num>")
def personal_hello(username, num=DEFAULT_GREETING_COUNT):
    greetings = [f"Hello, {username}"] * num
    return "\n".join(greetings)
