from argparse import ArgumentParser
import pytest

from asset import load_asset_from_file, process_cli_arguments, print_asset_revenue, setup_parser, setup_logging


def test_can_import_library():
    import asset


def test_process_can_load_asset(capsys, caplog):
    result = print_asset_revenue(open("asset.txt", mode='r', encoding='utf-8'), [1])
    expected_result = None
    captured = capsys.readouterr()

    assert '    1: 100000.000\n' == captured.out
    assert '' == captured.err
    assert "asset" not in captured.out
    assert "" in captured.err
    assert "" in captured.out
    assert "asset" not in captured.err
    
    assert expected_result == result, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )

def test_process_can_load_asset(capsys, caplog):

    parser = ArgumentParser(
        prog="asset",
        description="tool to forecast asset revenue",
    )
    setup_parser(parser)
    arguments = parser.parse_args(['--logging-config', 'task_Fedorov_Nikolay_asset_log.conf.yml', '--filepath', 'asset.txt', '--periods', '1'])
    setup_logging(arguments.logging_yaml_config_fpath)
    result = arguments.callback(arguments)
    expected_result = None
    captured = capsys.readouterr()

    assert expected_result == result, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )
    
    assert '    1: 100000.000\n' == captured.out, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )

    assert "WARNING" not in captured.err, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )


def test_process_can_load_asset_2(capsys, caplog):

    parser = ArgumentParser(
        prog="asset",
        description="tool to forecast asset revenue",
    )
    setup_parser(parser)
    arguments = parser.parse_args(['--logging-config', 'task_Fedorov_Nikolay_asset_log.conf.yml', '--filepath', 'asset.txt', '--periods', '1', '2', '3', '4', '5', '6', '7'])
    setup_logging(arguments.logging_yaml_config_fpath)
    result = arguments.callback(arguments)
    expected_result = None
    captured = capsys.readouterr()

    assert expected_result == result, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )

    assert "too many periods were provided" in captured.err, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )