python asset.py --logging-config task_Fedorov_Nikolay_asset_log.conf.yml --filepath asset.txt --periods 1 2 5

pytest -v --cov=asset task_Fedorov_Nikolay_asset.py