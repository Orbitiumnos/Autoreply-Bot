"""
cbr flask-app
"""

from flask import Flask
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)


@app.route("/")
def hello_world():
    ''' text '''
    return "Hello world!"


@app.errorhandler(404)
def page_not_found(error):
    ''' text '''
    message = 'This route is not found'
    return message, 404


def parse_cbr_currency_base_daily(html_data: str):
    ''' text '''

    def cleaning(list_to_clean):
        ''' text '''

        for i in list_to_clean:
            if i == "\n":
                list_to_clean.remove(i)
            if i == "\r":
                list_to_clean.remove(i)
        return list_to_clean

    def is_a_currency_tag(tag):
        ''' text '''

        if tag.name != "tr":
            return False
        my_link_siblings = list(tag.previous_siblings)
        my_link_siblings = cleaning(my_link_siblings)
        if len(my_link_siblings) == 0:
            return False
        header_link_childrens = my_link_siblings[-1].findChildren("th", recursive=False)
        column_names = [i.text for i in header_link_childrens]
        return bool('Rate' in column_names)

    cbr_soup = BeautifulSoup(html_data, features = 'html.parser')
    currency_dict = {}

    cbr_table_list = cbr_soup.find_all(is_a_currency_tag)

    for i in cbr_table_list:
        children = i.findChildren("td", recursive=False)
        if len(children) == 5:
            currency_dict[children[1].text] = float(children[4].text)/int(children[2].text)

    return currency_dict


@app.route("/cbr/daily")
def find_cbr_daily():
    ''' text '''

    #from pdb import set_trace; set_trace()
    try:
        cbr_response = requests.get('https://www.cbr.ru/eng/currency_base/daily/')
    except requests.exceptions.ConnectionError:
        return 'CBR service is unavailable', 503
    html_data = cbr_response.text
    return parse_cbr_currency_base_daily(html_data)


def parse_cbr_key_indicators(html_data: str):
    ''' text '''

    cbr_soup = BeautifulSoup(html_data, features = 'html.parser')

    indicators_dict = {}

    def is_internal_link(tag):
        if tag.name != "a":
            return False
        if not tag.has_attr("href"):
            return False
        return bool(tag.text in ("Foreign Currency Market", "Precious Metals"))

    res = cbr_soup.find_all(is_internal_link)

    for res2 in res:
        my_key = res2.parent.find_next_sibling("div")

        currency_ind_list = my_key.findAll("tr", attrs={"class": None})

        for i in currency_ind_list:
            currency_name = i.findAll("div", attrs={"class": ['_subinfo']})[-1]
            currency_value = i.findAll("td", attrs={"class": ['value']})[-1]
            currency_value = currency_value.text.replace(',','')
            indicators_dict[currency_name.text] = float(currency_value)

    return indicators_dict


@app.route("/cbr/key_indicators")
def find_cbr_key_indicators():
    ''' text '''

    try:
        cbr_response = requests.get('https://www.cbr.ru/eng/key-indicators/')
    except requests.exceptions.ConnectionError:
        return 'CBR service is unavailable', 503

    html_data = cbr_response.text
    return parse_cbr_key_indicators(html_data)
