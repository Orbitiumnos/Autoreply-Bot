import pytest
from task_Fedorov_Nikolay_asset_web_service import app
from unittest.mock import patch


@pytest.fixture
def client():
    with app.test_client() as client:
        yield client

def test_service_reply_to_root_path(client):
    response = client.get("/")
    assert 'world' in response.data.decode(response.charset)

def test_service_reply_to_currency(client):
    response = client.get("/cbr/daily")
    assert float(200) == float(response.status_code)

def test_service_reply_to_indicators(client):
    response = client.get("/cbr/key_indicators")
    assert float(200) == float(response.status_code)

def test_service_reply_to_404(client):
    response = client.get("/cbr/key")
    assert float(404) == float(response.status_code)

@patch("requests.get", return_value = ConnectionError)
def _test_service_reply_to_503(client):
    response = client.get("/cbr/daily")
    assert float(503) == float(response.status_code)


def _test_service_reply_to_username(client):
    response = client.get("/hello/Vasya")
    assert 'Vasya' in response.data.decode(response.charset)

def _test_service_reply_to_username_with_default_num(client):
    username = 'Vasya'
    expected_greeting_count = 10
    response = client.get("/hello/{username}")
    response_text = response.data.decode(response.charset)
    petya_count = response_text.count("Vasya")
    assert expected_greeting_count == petya_count

def _test_service_reply_to_username_several_times(client):
    username = 'Petya'
    expected_greeting_count = 15
    response = client.get("/hello/{username}/{expected_greeting_count}")
    response_text = response.data.decode(response.charset)
    petya_count = response_text.count("Petya")
    assert expected_greeting_count == petya_count

'''
1. /
2. currency
3. indicators
4. mock 503
'''
