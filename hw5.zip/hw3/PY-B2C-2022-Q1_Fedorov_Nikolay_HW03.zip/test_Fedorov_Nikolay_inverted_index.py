from textwrap import dedent
import os

import pytest

from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter, FileType, ArgumentTypeError

from task_Fedorov_Nikolay_inverted_index import InvertedIndex, load_documents, build_inverted_index, process_build, process_file_queries, process_queries, setup_parser

TEST_UTF8_PATH = "test_wikipedia_utf8.txt"
TEST_CP1251_PATH = "test_wikipedia_cp1251.txt"
INDEX_PATH = "inverted.index"
QUERY_UTF8_PATH = "test_query_utf8.txt"
QUERY_CP1251_PATH = "test_query_cp1251.txt" 

def test_can_import_inverted_index():
    import task_Fedorov_Nikolay_inverted_index


# тест на то, что load_documents корректно работает

def test_load_articles_utf8():
    data_folder = "."
    file_name = TEST_UTF8_PATH
    data_path = os.path.join(data_folder, file_name)
    result = load_documents(data_path)
    expected_result = {1: 'some words', 2: 'a'} #TODO

    assert expected_result == result, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )

def test_load_articles_cp1251():
    data_folder = "."
    file_name = TEST_CP1251_PATH
    data_path = os.path.join(data_folder,  file_name)
    result = load_documents(data_path)
    expected_result = {1: 'война мир', 2: 'аллегро'} #TODO

    assert expected_result == result, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )


# проверка на работу build_inverted_index (doc_id есть)

def test_build_inverted_index(): 
    test_case = {123: 'some words', 14: 'a'}
    result = build_inverted_index(test_case)
    expected_result = InvertedIndex({'some': [123],
    
     'words': [123], 'a': [14]})

    assert expected_result == result, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )

# проверка на работу build_inverted_index (doc_id нет)

def test_build_inverted_index_no_id(): 
    test_case = {None: 'some words', 14: 'a'}
    result = build_inverted_index(test_case)
    expected_result = InvertedIndex({'a': [14]})

    assert expected_result == result, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )

# проверка на работу build_inverted_index (слово еще не добавлено)

def test_build_inverted_index_new_word(): 
    test_case = {1: 'word'}
    result = build_inverted_index(test_case)
    expected_result = InvertedIndex({'word': [1]})

    assert expected_result == result, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )

# проверка на работу build_inverted_index (слово есть, но нет статьи)

def test_build_inverted_index_new_article(): 
    test_case = {1: 'word', 2: 'word'}
    result = build_inverted_index(test_case)
    expected_result = InvertedIndex({'word': [1, 2]})

    assert expected_result == result, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )

# проверка на работу build_inverted_index (слово есть и есть статья)

def test_build_inverted_index_duplicates(): 
    test_case = {1: 'word', 1: 'word'}
    result = build_inverted_index(test_case)
    expected_result = InvertedIndex({'word': [1]})

    assert expected_result == result, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )

# dump и load дают те же результаты

def test_json_dump_and_load():
    data_folder = "."
    file_name = INDEX_PATH
    filepath = os.path.join(data_folder,  file_name)
    inverted_index = InvertedIndex({'some': [123], 'words': [123], 'a': [14]})
    inverted_index.dump(filepath)
    result = InvertedIndex.load(filepath)
    expected_result = InvertedIndex({'some': [123], 'words': [123], 'a': [14]})

    assert expected_result == result, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )

def test_struct_dump_and_load():
    data_folder = "."
    file_name = INDEX_PATH
    filepath = os.path.join(data_folder,  file_name)
    inverted_index = InvertedIndex({'some': [123], 'words': [123], 'a': [14]})
    inverted_index.binary_dump(filepath)
    result = InvertedIndex.binary_load(filepath)
    expected_result = InvertedIndex({'some': [123], 'words': [123], 'a': [14]})

    assert expected_result == result, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )


# query - слово есть

def test_query(): 
    query_words = ['Some']
    inverted_index = InvertedIndex({'some': [1], 'words': [1], 'famous_phrases': [2], 'wait': [7], 'me': [7], '1': [7]})
    result = inverted_index.query(query_words)
    expected_result = [1]

    assert expected_result == result, (
        f"result should be {expected_result} "
        f"while your result is {result}"
    )

# query - слова нет

def test_empty_query(): 
    query_words = []
    inverted_index = InvertedIndex({'some': [1], 'words': [1], 'famous_phrases': [2], 'wait': [7], 'me': [7], '1': [7]})
    result = inverted_index.query(query_words)
    expected_result = []

    assert expected_result == result, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )

# query - слов несколько

def test_query_two_words(): 
    query_words = ['Some', 'words']
    inverted_index = InvertedIndex({'some': [1], 'words': [1], 'famous_phrases': [2], 'wait': [7], 'me': [7], '1': [7]})
    result = inverted_index.query(query_words)
    expected_result = [1]

    assert expected_result == result, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )

# query - слово не в том формате

def test_query_wrong_format(): 
    query_words = ['Some words']
    inverted_index = InvertedIndex({'some': [1], 'words': [1], 'famous_phrases': [2], 'wait': [7], 'me': [7], '1': [7]})
    result = inverted_index.query(query_words)
    expected_result = []

    assert expected_result == result, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )

# тест на process_build

def test_json_process_build():
    data_folder = "."
    file_name = TEST_UTF8_PATH
    data_path = os.path.join(data_folder,  file_name)
    index_name = INDEX_PATH
    index_path = os.path.join(data_folder,  index_name)

    dataset_filepath = data_path
    inverted_index_filepath = index_path
    store_strategy = 'json'

    process_build(dataset_filepath, inverted_index_filepath, store_strategy)
    result = InvertedIndex.load(index_path)
    expected_result = InvertedIndex({'some': [1], 'words': [1], 'a': [2]})

    assert expected_result == result, (
        f"result should be {expected_result} "
        f"while your result is {result}"
    )

def test_struct_process_build():
    data_folder = "."
    file_name = TEST_UTF8_PATH
    data_path = os.path.join(data_folder,  file_name)
    index_name = INDEX_PATH
    index_path = os.path.join(data_folder,  index_name)

    dataset_filepath = data_path
    inverted_index_filepath = index_path
    store_strategy = 'struct'

    process_build(dataset_filepath, inverted_index_filepath, store_strategy)
    result = InvertedIndex.binary_load(index_path)
    expected_result = InvertedIndex({'some': [1], 'words': [1], 'a': [2]})

    assert expected_result == result, (
        f"result should be {expected_result} "
        f"while your result is {result}"
    )


def test_all_process_utf8():
    data_folder = "."
    file_name = TEST_UTF8_PATH
    data_path = os.path.join(data_folder,  file_name)
    index_name = INDEX_PATH
    index_path = os.path.join(data_folder,  index_name)
    query_name = QUERY_UTF8_PATH
    query_path = os.path.join(data_folder,  query_name)

    dataset_filepath = data_path
    inverted_index_filepath = index_path
    store_strategy = 'json'
    query_file = query_path
    load_strategy = 'json'

    process_build(dataset_filepath, inverted_index_filepath, store_strategy)
    result = process_file_queries(inverted_index_filepath, query_file, load_strategy)
    expected_result = None

    assert expected_result == result, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )

def test_all_process_utf8_struct():
    data_folder = "."
    file_name = TEST_UTF8_PATH
    data_path = os.path.join(data_folder,  file_name)
    index_name = INDEX_PATH
    index_path = os.path.join(data_folder,  index_name)
    
    dataset_filepath = data_path
    inverted_index_filepath = index_path
    store_strategy = 'struct'
    query_file = ['some words']
    load_strategy = 'struct'

    process_build(dataset_filepath, inverted_index_filepath, store_strategy)
    result = process_file_queries(inverted_index_filepath, query_file, load_strategy)
    expected_result = None

    assert expected_result == result, (
        f"result should be {expected_result} "
        f"while your result is {result}"
    )

def test_all_process_cp1251_json():
    data_folder = "."
    file_name = TEST_UTF8_PATH
    data_path = os.path.join(data_folder,  file_name)
    index_name = INDEX_PATH
    index_path = os.path.join(data_folder,  index_name)
    
    dataset_filepath = data_path
    inverted_index_filepath = index_path
    store_strategy = 'json'
    query_file = ['новый мир']
    load_strategy = 'json'

    process_build(dataset_filepath, inverted_index_filepath, store_strategy)
    result = process_file_queries(inverted_index_filepath, query_file, load_strategy)
    expected_result = None

    assert expected_result == result, (
        f"result should be {expected_result} "
        f"while your result is {result}"
    )

def test_all_process_cp1251_struct():
    data_folder = "."
    file_name = TEST_UTF8_PATH
    data_path = os.path.join(data_folder,  file_name)
    index_name = INDEX_PATH
    index_path = os.path.join(data_folder,  index_name)
    
    dataset_filepath = data_path
    inverted_index_filepath = index_path
    store_strategy = 'struct'
    query_file = ['новый мир']
    load_strategy = 'struct'

    process_build(dataset_filepath, inverted_index_filepath, store_strategy)
    result = process_file_queries(inverted_index_filepath, query_file, load_strategy)
    expected_result = None

    assert expected_result == result, (
        f"result should be {expected_result} "
        f"while your result is {result}"
    )


def test_all_process(): 
    query_words = ['Some words']
    inverted_index = InvertedIndex({'some': [1], 'words': [1], 'famous_phrases': [2], 'wait': [7], 'me': [7], '1': [7]})
    result = inverted_index.query(query_words)
    expected_result = []

    assert expected_result == result, (
        f"result should be {expected_result}"
        f"while your result is {result}"
    )


def test_process_queries_struct():
    data_folder = "."
    file_name = TEST_UTF8_PATH
    data_path = os.path.join(data_folder,  file_name)
    index_name = INDEX_PATH
    index_path = os.path.join(data_folder,  index_name)
    

    inverted_index = InvertedIndex({'some': [1], 'words': [1], 'famous_phrases': [2], 'wait': [7], 'me': [7], '1': [7]})
    inverted_index.binary_dump(index_path)
    inverted_index_filepath = index_path

    load_strategy = 'struct'
    query = [['some words']]
    
    result = process_queries(inverted_index_filepath, query, load_strategy)
    expected_result = None

    assert expected_result == result, (
        f"result should be {expected_result} "
        f"while your result is {result}"
    )

def test_process_queries_json():
    data_folder = "."
    file_name = TEST_UTF8_PATH
    data_path = os.path.join(data_folder,  file_name)
    index_name = INDEX_PATH
    index_path = os.path.join(data_folder,  index_name)
    

    inverted_index = InvertedIndex({'some': [1], 'words': [1], 'famous_phrases': [2], 'wait': [7], 'me': [7], '1': [7]})
    inverted_index.dump(index_path)
    inverted_index_filepath = index_path

    load_strategy = 'json'
    query = [['some words']]
    
    result = process_queries(inverted_index_filepath, query, load_strategy)
    expected_result = None

    assert expected_result == result, (
        f"result should be {expected_result} "
        f"while your result is {result}"
    )

def test_parser():

    parser = ArgumentParser(
        prog="inverted_index_cli.py",
        description='Inverted Index CLI',
        formatter_class=ArgumentDefaultsHelpFormatter,
    )

    setup_parser(parser)
    result = parser.parse_args(['build', '--strategy', 'json', '--dataset', r'C:\Users\Nikolay\repos\PythonCourse\hw3\wikipedia_cp1251.txt', '--output',  r'C:\Users\Nikolay\repos\PythonCourse\hw3\inverted.index'])

    expected_result = Namespace()

    assert expected_result == result, (
        f"result should be {expected_result} "
        f"while your result is {result}"
    )

