python task_Fedorov_Nikolay_inverted_index.py -h

python task_Fedorov_Nikolay_inverted_index.py --help


python task_Fedorov_Nikolay_inverted_index.py build --strategy json --dataset C:\Users\Nikolay\repos\PythonCourse\hw3\wikipedia_utf8.txt --output C:\Users\Nikolay\repos\PythonCourse\hw3\inverted.index

python task_Fedorov_Nikolay_inverted_index.py build --strategy struct --dataset C:\Users\Nikolay\repos\PythonCourse\hw3\wikipedia_utf8.txt --output C:\Users\Nikolay\repos\PythonCourse\hw3\inverted.index

python task_Fedorov_Nikolay_inverted_index.py build --dataset C:\Users\Nikolay\repos\PythonCourse\hw3\wikipedia_test_utf8.txt --output C:\Users\Nikolay\repos\PythonCourse\hw3\inverted.index

python task_Fedorov_Nikolay_inverted_index.py query --index C:\Users\Nikolay\repos\PythonCourse\hw3\inverted.index --strategy json --query-file-utf8 C:\Users\Nikolay\repos\PythonCourse\hw3\query_utf8.txt




python task_Fedorov_Nikolay_inverted_index.py build --strategy json --dataset C:\Users\Nikolay\repos\PythonCourse\hw3\wikipedia_test_cp1251.txt --output C:\Users\Nikolay\repos\PythonCourse\hw3\inverted.index

python task_Fedorov_Nikolay_inverted_index.py build --strategy struct --dataset C:\Users\Nikolay\repos\PythonCourse\hw3\wikipedia_test_cp1251.txt --output C:\Users\Nikolay\repos\PythonCourse\hw3\inverted.index

python task_Fedorov_Nikolay_inverted_index.py build --dataset C:\Users\Nikolay\repos\PythonCourse\hw3\wikipedia_test_cp1251.txt --output C:\Users\Nikolay\repos\PythonCourse\hw3\inverted.index 9653


python task_Fedorov_Nikolay_inverted_index.py query --index C:\Users\Nikolay\repos\PythonCourse\hw3\inverted.index --strategy json --query some words --query a --query a b

python task_Fedorov_Nikolay_inverted_index.py query --index C:\Users\Nikolay\repos\PythonCourse\hw3\inverted.index --strategy struct --query some words --query total war

python task_Fedorov_Nikolay_inverted_index.py query --index C:\Users\Nikolay\repos\PythonCourse\hw3\inverted.index --strategy json --query some words --query a --query a b

python task_Fedorov_Nikolay_inverted_index.py query --index C:\Users\Nikolay\repos\PythonCourse\hw3\inverted.index --strategy struct --query some words --query total war



python task_Fedorov_Nikolay_inverted_index.py build --strategy struct --dataset C:\Users\Nikolay\repos\PythonCourse\hw3\wikipedia_test.txt --output C:\Users\Nikolay\repos\PythonCourse\hw3\inverted.index

python task_Fedorov_Nikolay_inverted_index.py query --index C:\Users\Nikolay\repos\PythonCourse\hw3\inverted.index --strategy struct --query some words --query a --query война мир

python task_Fedorov_Nikolay_inverted_index.py query --index C:\Users\Nikolay\repos\PythonCourse\hw3\inverted.index --strategy json --query a --query мир





python task_Fedorov_Nikolay_inverted_index.py query --index C:\Users\Nikolay\repos\PythonCourse\hw3\inverted.index --query-file-utf8 /path/to/quries.txt

cat /path/to/quries.txt | python task_Fedorov_Nikolay_inverted_index.py query --index /path/to/inverted.index --strategy struct --query-file-utf8

python task_Fedorov_Nikolay_inverted_index.py query --index C:\Users\Nikolay\repos\PythonCourse\hw3\inverted.index --strategy struct --query-file-cp1251 C:\Users\Nikolay\repos\PythonCourse\hw3\query_cp1251.txt

cat /path/to/quries.txt | python task_Fedorov_Nikolay_inverted_index.py query --index /path/to/inverted.index --strategy struct --query-file-cp1251




--callback_build
	process_build
		load_documents
		build_inverted_index
		binary_dump
		dump
callback_query
	process_queries
		binary_load
		load
	process_file_queries


Namespace(dataset_filepath='C:\\Users\\Nikolay\\repos\\PythonCourse\\hw3\\wikipedia_test_cp1251.txt', store_strategy='json', inverted_index_filepath='C:\\Users\\Nikolay\\repos\\PythonCourse\\hw3\\inverted.index', callback=<function callback_build at 0x00000161C0FDAAF0>)



pytest -v --cov=task_Fedorov_Nikolay_inverted_index test_Fedorov_Nikolay_inverted_index.py




