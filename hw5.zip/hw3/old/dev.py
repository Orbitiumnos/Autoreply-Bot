import sys, os
import codecs
path = r'C:\Users\Nikolay\repos\PythonCourse\hw3\wikipedia_test_cp1251.txt'
output = r'C:\Users\Nikolay\repos\PythonCourse\hw3\output'
#with open('C:\Users\Nikolay\repos\PythonCourse\hw3\wikipedia_test_cp1251.txt', 'rb', encoding='cp1251') as f:
#    #res = f.readlines
#    contents = f.read().decode("cp1251")
#f.close()
#print(contents)


#f = codecs.open(path, 'r', 'cp1251')
#u = f.read()   # now the contents have been transformed to a Unicode string
#out = codecs.open(output, 'w', 'utf-8')
#out.write(u)   # and now the contents have been output as UTF-8


#words = ['total','war']
#search_words = list(filter(None, words))
#search_words = set(search_words)
#similar_words = search_words & set(index_dict.keys())

res = os.path.join('.', 'test', 'file.txt')
print(res)