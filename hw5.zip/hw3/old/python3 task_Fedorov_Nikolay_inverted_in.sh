python3 task_Fedorov_Nikolay_inverted_index.py -h
python3 task_Fedorov_Nikolay_inverted_index.py --help

python3 task_Fedorov_Nikolay_inverted_index.py build --strategy json --dataset /mnt/c/Users/Nikolay/Repos/PythonCourse/hw1/wikipedia_sample --output /mnt/c/Users/Nikolay/Repos/PythonCourse/inverted.index

python3 task_Fedorov_Nikolay_inverted_index.py build --strategy struct --dataset /mnt/c/Users/Nikolay/Repos/PythonCourse/hw1/wikipedia_sample --output /mnt/c/Users/Nikolay/Repos/PythonCourse/inverted.index

python3 task_Fedorov_Nikolay_inverted_index.py build --dataset /mnt/c/Users/Nikolay/Repos/PythonCourse/hw1/wikipedia_sample --output /mnt/c/Users/Nikolay/Repos/PythonCourse/inverted.index



python3 task_Fedorov_Nikolay_inverted_index.py query --index /mnt/c/Users/Nikolay/Repos/PythonCourse/inverted.index --strategy struct --query two words --query lol kek --query total war

python3 task_Fedorov_Nikolay_inverted_index.py query --index /mnt/c/Users/Nikolay/Repos/PythonCourse/inverted.index --strategy json --query two words --query lol kek --query total war

python3 task_Fedorov_Nikolay_inverted_index.py query --index /mnt/c/Users/Nikolay/Repos/PythonCourse/inverted.index --query-file-utf8 /mnt/c/Users/Nikolay/Repos/PythonCourse/hw3/query_utf8.txt

cat /mnt/c/Users/Nikolay/Repos/PythonCourse/hw3/query_utf8.txt | python3 task_Fedorov_Nikolay_inverted_index.py query --index /mnt/c/Users/Nikolay/Repos/PythonCourse/inverted.index --strategy struct --query-file-utf8 -

python3 task_Fedorov_Nikolay_inverted_index.py query --index /mnt/c/Users/Nikolay/Repos/PythonCourse/inverted.index --strategy struct --query-file-cp1251 /mnt/c/Users/Nikolay/Repos/PythonCourse/hw3/query_cp1251.txt

cat /path/to/quries.txt | python3 task_Fedorov_Nikolay_inverted_index.py query
--index /path/to/inverted.index --strategy struct --query-file-cp1251 - 